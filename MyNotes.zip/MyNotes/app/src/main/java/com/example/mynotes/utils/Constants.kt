package com.example.mynotes.utils

object Constants {

    const val DATABASE_NAME = "note_database.db"

}