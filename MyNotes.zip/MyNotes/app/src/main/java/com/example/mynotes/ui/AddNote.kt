package com.example.mynotes.ui

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.mynotes.databinding.ActivityAddNoteBinding
import com.example.mynotes.model.NoteDto
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.Date

class AddNote : AppCompatActivity() {

    lateinit var oldNote: NoteDto
    lateinit var note: NoteDto
    var isUpdate: Boolean = false
    lateinit var binding: ActivityAddNoteBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)


        try {
            oldNote = intent.getSerializableExtra("current_note") as NoteDto
            binding.etTitle.setText(oldNote.title)
            binding.etNote.setText(oldNote.description)
            isUpdate = true
        }catch (e: Exception){
            e.printStackTrace()
        }

        binding.imgSaveBtn.setOnClickListener {

            val title = binding.etTitle.text.toString()
            val note_des = binding.etNote.text.toString()

            if (title.isNotEmpty() || note_des.isNotEmpty()){

                val formatter = SimpleDateFormat("EEE, d MM yyyy HH:mm a")

                if (isUpdate) {
                    note = NoteDto(
                        oldNote.id, title, note_des, formatter.format(Date())
                    )
                }
                else{
                    note = NoteDto(
                        null,title, note_des, formatter.format(Date())
                    )
                }

                val intent = Intent()
                intent.putExtra("note", note)
                setResult(Activity.RESULT_OK, intent)
                finish()

            }
            else{

                Toast.makeText(this@AddNote, "Please Enter Some Data", Toast.LENGTH_SHORT).show()
                return@setOnClickListener

            }

        }

        binding.imgBackBtn.setOnClickListener {

            onBackPressed()

        }

    }
}