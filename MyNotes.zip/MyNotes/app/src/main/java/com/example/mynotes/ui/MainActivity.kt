package com.example.mynotes.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.lifecycle.ViewModelProvider
import com.example.mynotes.R
import com.example.mynotes.adapter.NoteAdapter
import com.example.mynotes.database.NoteDatabase
import com.example.mynotes.databinding.ActivityMainBinding
import com.example.mynotes.interfaces.OnItemClickListener
import com.example.mynotes.model.NoteDto
import com.example.mynotes.viewmodel.NoteViewModel


class MainActivity : AppCompatActivity(), OnItemClickListener {

    lateinit var viewModel: NoteViewModel
    lateinit var adapter: NoteAdapter
    lateinit var database: NoteDatabase
    lateinit var selectedNote : NoteDto

    //Update Note ->
    private val updateNote = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){

        if (it.resultCode == Activity.RESULT_OK){

            val note = it.data?.getSerializableExtra("note") as? NoteDto
            if (note != null){
                viewModel.updateNote(note)
            }
        }

    }

    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialization of UI

        initialize()

        //View Model init

        viewModel = ViewModelProvider(this,
            ViewModelProvider
                .AndroidViewModelFactory
                .getInstance(application))[NoteViewModel::class.java]

        viewModel.allNotes.observe(this) {
            it?.let {
                adapter.updateList(it)
            }
        }

        database = NoteDatabase.getDatabase(this)

        //fbAddNote ->



    }

    private fun initialize() {
        adapter = NoteAdapter(this, this)
        binding.rvNotes.adapter = adapter

        val getcontent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            if (it.resultCode == RESULT_OK) {
                val note = it.data?.getSerializableExtra("note") as? NoteDto
                note?.let {
                    viewModel.insertNote(note)
                }
            }
        }

        binding.fbAdd.setOnClickListener {

            val intent = Intent(this, AddNote::class.java)
            getcontent.launch(intent)

        }

        //SearchView ->
        binding.searchView.setOnQueryTextListener(object : android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {

                if (newText != null){
                    adapter.filterList(newText)
                }

                return true
            }

        })
    }

    override fun OnItemClick(note: NoteDto) {
        val intent = Intent(this, AddNote::class.java)
        intent.putExtra("current_note", note)
        updateNote.launch(intent)
    }

    override fun OnLongItemclicked(note: NoteDto, cardView: CardView) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Delete this Note")
        builder.setMessage("Are you sure to delete this note ?")
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        builder.setPositiveButton("Yes"){dialog, id ->

            selectedNote = note
            viewModel.deleteNote(selectedNote)

        }

        builder.setNegativeButton("No"){dialog, id->

            dialog.cancel()

        }

        val alertDialog: AlertDialog = builder.create()

        alertDialog.setCancelable(false)
        alertDialog.show()
    }
}